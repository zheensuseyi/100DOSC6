// Zheen H. Suseyi
// 09/23/2024

/*
 To check your knowledge, here’s a small task for you: 
 create a struct to store information about a car, including its model, number of seats, and current gear, then add a method to change gears up or down.
 Have a think about variables and access control: what data should be a variable rather than a constant, and what data should be exposed publicly? Should the gear-changing method validate its input
 somehow?
 */

import UIKit

// making our car object
struct Car {
    // error checker if a gear somehow goes above 6
    enum gearError: Error {
        case outofbounds
    }
    // defining our variables
    let model = "Hyundai"
    let seats = 5
    private var currentGear = 0
    
    // function for changing gears
    mutating func gearChange(accel: Bool) throws -> String {
        // if car is accelerating
        if accel {
            // if the currentGear is less then 6, print the current gear and then move on to the next gear and print that
            if currentGear < 6 {
                print("The car is accelerating! Now in gear \(currentGear).")
                currentGear += 1
                return "Gear is going up! Current gear is \(currentGear)"
            }
            // else if the current gear is 6, return that they have reached the final gear
            else if currentGear == 6 {
                return "You reached the final gear speed racer!"
            }
            // else, throw an outofbounds error
            else {
                throw gearError.outofbounds
            }
        }
        // if the car is not accelerating
        else {
            // if the currentGear is greater then 0, the current gear will subtract and be printed until its at 6
            if currentGear > 0  {
                currentGear -= 1
                print("The car is decelerating!")
                } 
                // if gear == 0 return
                else {
                        return "You're at the lowest gear! You can't go lower."
                    }
                }
                // return us our current gear
                return "The car is now in gear \(currentGear)."
    }
}
// Testing our function 6 seperate times
do {
    var myCar = Car()
    try print(myCar.gearChange(accel: true))
    try print(myCar.gearChange(accel: true))
    try print(myCar.gearChange(accel: true))
    try print(myCar.gearChange(accel: true))
    try print(myCar.gearChange(accel: true))
    try print(myCar.gearChange(accel: true))
}

// Catching an outofbounds error
catch Car.gearError.outofbounds{
    print("What the sigma are you doing!!! You've exceeded the gear limit.")
}
